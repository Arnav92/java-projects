import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class JLabelTest extends JFrame {
	private JLabel a;
	public JLabelTest () {
		super("Test23980");
		setLayout(new FlowLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(150, 150);
		setVisible(true);
		
		a = new JLabel("Test23980");
		a.setBounds(100, 100, 100, 100);
		add(a);
	}
}


