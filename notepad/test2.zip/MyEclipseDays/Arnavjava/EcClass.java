class EcClass {
	public static void main (String args[]) {
		TextInJFrame tij = new TextInJFrame();
}
	}