import java.awt.FlowLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class TextInJFrame {
	public TextInJFrame () {
	Everything f = new Everything();
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	f.setSize(150, 150);
	f.setVisible(true);
}
}

class Everything extends JFrame {
	private JLabel Timer;
	private String b;

	public Everything () {
	super("10 second CPS test");
	setLayout(new FlowLayout());

	JLabel a = new JLabel("Default");
	add(a);
	
	Mouseclass clicked = new Mouseclass();
	
	a.addMouseListener(clicked);
}
	private class Mouseclass extends MouseAdapter {
		public void mouseClicked (MouseEvent event) {
			try {
			b = String.format("You have clicked %s number of times", event.getClickCount());
			
			a.setText("jhgjhghjg");
			
			if (event.getClickCount() <= 1 && event.getSource() == a) {
			for (int x = 10; x >= 0;) {
				JLabel Timer = new JLabel("Test");
				Timer.setBounds(50, 50, 100, 100);
				Timer.setText(Integer.toString(x));
				add(Timer);
				
				try {
					Thread.sleep(1000); 
					x--;
				}
					catch (InterruptedException ie) {
					Thread.currentThread().interrupt();
					}
					if (x == 0) {
					System.out.println("Time's up!!");
			}
			}
			}
			}
			catch (Exception e) {
			System.out.println("Oops");	
			}
			}
			}
			}